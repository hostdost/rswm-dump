<?php

class SiteOrigin_Widget_ContactForm_Field_Tel extends SiteOrigin_Widget_ContactForm_Field_Text {
	// This class just exists for autoloading purposes, but is the same as the text field.
}
